import React from "react";
import logo from "./logo.png";
import "./App.css";

function App() {
  return (
    <div style={{ textAlign: "center", background: "#000", minHeight: "100vh" }}>
      <nav style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        padding: "1rem 2rem",
        backgroundColor: "#111",
        borderBottom: "2px solid #ff00cc"
      }}>
        <div style={{ display: "flex", alignItems: "center" }}>
          <img src={logo} alt="Logo" style={{ height: 50, marginRight: 10 }} />
          <h1 style={{ color: "#ff66cc", fontSize: "1.5rem" }}>MyPartyPlug</h1>
        </div>
        <div style={{ display: "flex", gap: "1.5rem" }}>
          {["Home", "Events", "About", "Contact"].map((item) => (
            <a key={item} href={"#" + item.toLowerCase()} style={{ color: "#fff", textDecoration: "none" }}>
              {item}
            </a>
          ))}
        </div>
      </nav>
      <main style={{ padding: "2rem" }}>
        <h2 style={{ color: "#ff66cc" }}>Welcome to MyPartyPlug</h2>
        <p style={{ color: "#ccc" }}>Discover the best events, nightlife, and parties happening near you!</p>
      </main>
    </div>
  );
}

export default App;